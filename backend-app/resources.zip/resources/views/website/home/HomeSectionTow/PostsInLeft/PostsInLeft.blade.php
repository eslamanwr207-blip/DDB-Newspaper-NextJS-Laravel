<div class="PostsInLeft" >

    <div class='ParentOtherPostsInLeft'>

        @include('website.home.HomeSectionTow.PostsInLeft.MainPostInLeft')


        @include('website.home.HomeSectionTow.PostsInLeft.OtherPostsInLeft')




    </div>
</div>
