<div class="PostsInLeft" >

    <div class='ParentOtherPostsInLeft'>

        @include('website.home.HomeSectionTow.PostsInRight.MainPostInRight')


        @include('website.home.HomeSectionTow.PostsInRight.OtherPostInRight')




    </div>
</div>
