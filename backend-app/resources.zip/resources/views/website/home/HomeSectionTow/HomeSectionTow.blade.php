<div class="HomeSectionTow" >

    @include('website.home.HomeSectionTow.PostsInLeft.PostsInLeft')
    @include('website.home.HomeSectionTow.MainPostInSectionTow')
    @include('website.home.HomeSectionTow.PostsInRight.PostsInRight')
</div>
