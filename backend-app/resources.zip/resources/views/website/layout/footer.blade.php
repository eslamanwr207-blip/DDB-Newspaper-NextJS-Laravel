<div class="container" >
    <div class="Footer" >
        <h1 class="logo" >DDB</h1>
        @include('website.layout.categories')

        <p>Copyright 2025 DDB. All rights reserved.  The DDB is not responsible for the content of external sites</p>
    </div>
</div>
